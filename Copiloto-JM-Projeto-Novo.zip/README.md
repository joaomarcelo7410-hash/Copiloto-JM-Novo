# Copiloto JM

Aplicativo Android para motoristas de aplicativo, adaptado a partir do projeto open-source **Vale a Corrida**. O app lê ofertas de Uber, 99 e inDrive quando os serviços estão habilitados, calcula rentabilidade por km/h e exibe um cartão sobre a oferta. Também possui simulador e registro de gastos.

## Recursos herdados da base
- Leitura de ofertas por serviço de acessibilidade e OCR local.
- Cartão flutuante com avaliação por critérios configuráveis.
- Simulador, configuração de valores e controle de gastos/relatórios.
- Não aceita nem recusa corridas automaticamente.
- A base informa que a Uber foi testada em Xiaomi/Android 15; 99 e inDrive não estavam confirmados pelo autor upstream. Teste local é necessário.

## Identidade
- Nome do app: Copiloto JM
- Ícone: logo fornecida pelo proprietário do projeto
- Application ID: `com.copilotojm.app`
- Versão: 0.3.0 (adaptação inicial)

## Build no GitHub Actions
O workflow em `.github/workflows/android.yml` executa build Android e disponibiliza o APK debug como artifact. Use Actions > Build Copiloto JM > Run workflow, ou envie alterações para `main`.

## Compilar localmente
JDK 17 e Android SDK:
```bash
./gradlew test
./gradlew :app:assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Licença e créditos
A base original é distribuída sob MIT. A licença original foi preservada em `LICENSE`; os avisos de autoria e licença devem ser mantidos. Este projeto é uma adaptação independente e não tem vínculo com Uber, 99 ou inDrive.
